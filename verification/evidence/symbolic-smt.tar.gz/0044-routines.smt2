; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun argument_0 () (_ BitVec 32))
(assert (bvule argument_0 (_ bv255 32)))
(assert (bvugt argument_0 (_ bv255 32)))
(check-sat)
