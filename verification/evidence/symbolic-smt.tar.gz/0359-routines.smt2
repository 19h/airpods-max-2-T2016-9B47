; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun argument_0 () (_ BitVec 32))
(assert (bvule argument_0 (_ bv4294967295 32)))
(assert (not (or (and (bvule argument_0 (_ bv4294967295 32)) (distinct (bvand (bvnot argument_0) (_ bv1111490560 32)) (_ bv0 32)) (= (bvnot (bvxor (ite (= (bvand (bvnot argument_0) (_ bv1145307136 32)) (_ bv0 32)) (_ bv1 1) (_ bv0 1)) (_ bv1 1))) (_ bv0 1))) (and (bvule argument_0 (_ bv4294967295 32)) (= (bvand (bvnot argument_0) (_ bv1111490560 32)) (_ bv0 32))) (and (bvule argument_0 (_ bv4294967295 32)) (distinct (bvand (bvnot argument_0) (_ bv1111490560 32)) (_ bv0 32)) (distinct (bvnot (bvxor (ite (= (bvand (bvnot argument_0) (_ bv1145307136 32)) (_ bv0 32)) (_ bv1 1) (_ bv0 1)) (_ bv1 1))) (_ bv0 1))))))
(check-sat)
