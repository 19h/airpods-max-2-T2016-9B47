; benchmark generated from clarirs
(set-info :status unknown)
(assert false)
(check-sat)
