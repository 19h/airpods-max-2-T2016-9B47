; benchmark generated from clarirs
(set-info :status unknown)
(check-sat)
