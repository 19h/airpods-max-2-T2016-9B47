; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun response_4d000000_4_0 () (_ BitVec 32))
(declare-fun response_4d000000_4_1 () (_ BitVec 32))
(assert (distinct (bvsub (ite (= ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))) (_ bv65 8)) ((_ zero_extend 28) ((_ extract 3 0) (bvlshr response_4d000000_4_1 (_ bv8 32)))) ((_ zero_extend 24) ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))))) (ite (= ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))) (_ bv65 8)) (_ bv0 32) (_ bv65 32))) (_ bv0 32)))
(assert (= (bvsub (ite (= ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))) (_ bv65 8)) ((_ zero_extend 28) ((_ extract 3 0) (bvlshr response_4d000000_4_1 (_ bv8 32)))) ((_ zero_extend 24) ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))))) (ite (= ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))) (_ bv65 8)) (_ bv1 32) (_ bv65 32))) (_ bv0 32)))
(assert (distinct (bvsub (ite (= ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))) (_ bv65 8)) ((_ zero_extend 28) ((_ extract 3 0) (bvlshr response_4d000000_4_1 (_ bv8 32)))) ((_ zero_extend 24) ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))))) (ite (= ((_ extract 7 0) (bvlshr response_4d000000_4_0 (_ bv12 32))) (_ bv65 8)) (_ bv1 32) (_ bv65 32))) (_ bv0 32)))
(check-sat)
