; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun argument_0 () (_ BitVec 32))
(assert (bvule argument_0 (_ bv4294967295 32)))
(assert (= (ite (distinct (bvxor (ite (= (bvand (bvnot argument_0) (_ bv1111941120 32)) (_ bv0 32)) (_ bv1 32) (_ bv0 32)) (_ bv1 32)) (_ bv0 32)) (bvand (bvnot argument_0) (_ bv1111490560 32)) (bvand (bvnot argument_0) (_ bv1111941120 32))) (_ bv0 32)))
(assert (= (bvand (bvnot argument_0) (_ bv1111490560 32)) (_ bv0 32)))
(assert false)
(check-sat)
