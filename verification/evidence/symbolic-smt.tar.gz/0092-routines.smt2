; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun initial_4d28996c () (_ BitVec 8))
(declare-fun initial_4d2899a8 () (_ BitVec 8))
(assert (not (or (distinct initial_4d2899a8 (_ bv1 8)) (and (= initial_4d2899a8 (_ bv1 8)) (= initial_4d28996c (_ bv255 8))) (and (= initial_4d2899a8 (_ bv1 8)) (distinct initial_4d28996c (_ bv255 8))))))
(check-sat)
