; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun argument_0 () (_ BitVec 32))
(declare-fun response_4d159000_4_0 () (_ BitVec 32))
(assert (bvule argument_0 (_ bv255 32)))
(assert (distinct (concat (_ bv1430585868292 41) ((_ zero_extend 32) (bvor (bvand (bvshl argument_0 (_ bv12 32)) (_ bv28672 32)) (bvand response_4d159000_4_0 (_ bv4294938623 32))))) (concat (_ bv1430585868292 41) ((_ zero_extend 32) (bvor (bvand response_4d159000_4_0 (_ bv4294938623 32)) (bvshl (bvand argument_0 (_ bv7 32)) (_ bv12 32)))))))
(check-sat)
