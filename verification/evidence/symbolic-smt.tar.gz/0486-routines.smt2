; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun argument_0 () (_ BitVec 32))
(assert (= argument_0 (_ bv1294468541 32)))
(assert (bvule argument_0 (_ bv4294967295 32)))
(check-sat)
