; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun argument_0 () (_ BitVec 32))
(assert (bvule argument_0 (_ bv4294967295 32)))
(assert (distinct (bvnot (bvand (ite (bvuge (bvadd (bvlshr argument_0 (_ bv2 32)) (_ bv4294967295 32)) (_ bv2 32)) (_ bv1 1) (_ bv0 1)) (bvnot (ite (= (bvlshr argument_0 (_ bv2 32)) (_ bv3 32)) (_ bv1 1) (_ bv0 1))))) (_ bv0 1)))
(check-sat)
