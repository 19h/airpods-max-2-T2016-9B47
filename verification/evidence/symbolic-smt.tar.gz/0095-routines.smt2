; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun initial_4d2899a8 () (_ BitVec 8))
(assert (distinct initial_4d2899a8 (_ bv1 8)))
(assert (distinct (bvxor (ite (= initial_4d2899a8 (_ bv1 8)) (_ bv1 1) (_ bv0 1)) (_ bv1 1)) (_ bv0 1)))
(assert false)
(check-sat)
