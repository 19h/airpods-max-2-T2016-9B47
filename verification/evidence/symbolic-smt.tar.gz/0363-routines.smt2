; benchmark generated from clarirs
(set-info :status unknown)
(declare-fun argument_0 () (_ BitVec 32))
(assert (bvule argument_0 (_ bv4294967295 32)))
(assert (distinct (ite (distinct (bvxor (ite (= (bvand (bvnot argument_0) (_ bv1111941120 32)) (_ bv0 32)) (_ bv1 32) (_ bv0 32)) (_ bv1 32)) (_ bv0 32)) (bvand (bvnot argument_0) (_ bv1111490560 32)) (bvand (bvnot argument_0) (_ bv1111941120 32))) (_ bv0 32)))
(assert (= (bvnot (bvxor (ite (= (bvand (bvnot argument_0) (_ bv1145307136 32)) (_ bv0 32)) (_ bv1 1) (_ bv0 1)) (_ bv1 1))) (_ bv0 1)))
(assert (distinct (bvand (bvnot argument_0) (_ bv1111490560 32)) (_ bv0 32)))
(assert (distinct (bvnot (bvxor (ite (= (bvand (bvnot argument_0) (_ bv1145307136 32)) (_ bv0 32)) (_ bv1 1) (_ bv0 1)) (_ bv1 1))) (_ bv0 1)))
(check-sat)
